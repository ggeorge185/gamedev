import {
  require_react
} from "./chunk-TVFQMRVC.js";
import "./chunk-G3PMV62Z.js";
export default require_react();
